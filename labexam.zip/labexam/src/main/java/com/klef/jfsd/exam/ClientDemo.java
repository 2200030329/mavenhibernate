package com.klef.jfsd.exam;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class ClientDemo {

	public static void main(String[] args) {
	
        // Create SessionFactory
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

        // Open Session
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        // Create and Save Car
        Car car = new Car();
        car.setName("Sedan");
        car.setType("Car");
        car.setMaxSpeed(180);
        car.setColor("Red");
        car.setNumberOfDoors(4);
        session.save(car);

        // Create and Save Truck
        Truck truck = new Truck();
        truck.setName("Pickup");
        truck.setType("Truck");
        truck.setMaxSpeed(120);
        truck.setColor("Blue");
        truck.setLoadCapacity(2000);
        session.save(truck);

        // Commit Transaction
        session.getTransaction().commit();

        // Close Session and SessionFactory
        session.close();
        sessionFactory.close();

        System.out.println("Records inserted successfully!");
    }
}




